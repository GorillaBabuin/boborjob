using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BobContr : MonoBehaviour
{
    // Start is called before the first frame update
    float vertical;
    float horiz;
    Rigidbody rb;
    Transform tr;
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        tr = GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        vertical = Input.GetAxis("Vertical");
        horiz = Input.GetAxis("Horizontal");
        rb.AddRelativeForce(0,0, vertical * 4f);
        tr.Rotate(0,horiz/2,0);
    }
    void walk(){
         rb.AddForce(10,0,0); 
    }
}
